
CREATE VIEW количество_детей_в_отряде AS 
  SELECT Отряд.код AS код, Отряд.название, (SELECT COUNT(*) FROM Ребёнок WHERE Ребёнок.код_отряда = Отряд.код) AS количество 
    FROM Отряд
go

