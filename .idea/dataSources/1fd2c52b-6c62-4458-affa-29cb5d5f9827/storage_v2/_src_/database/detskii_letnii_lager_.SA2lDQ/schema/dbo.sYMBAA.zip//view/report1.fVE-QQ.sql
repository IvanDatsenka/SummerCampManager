create view report1 as
select Отряд.название as название, count(*) as количество_детей
from Отряд inner join Ребёнок on Отряд.код=Ребёнок.код_отряда
group by Отряд.название
go

